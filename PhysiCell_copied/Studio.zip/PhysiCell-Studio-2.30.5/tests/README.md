This directory is used for running pytests on the Studio. Dependencies: `pytest`, `pytest-qt` (pip installable).

To test, run the following command from this (/tests) directory:
```
pytest test_studio.py -s
```
